from django.contrib import admin
from django.urls import path, include
from .views import Login, Signup, Index, Cart, Checkout, OrderView
from . import views
from .middleware.authorization import auth_middleware


urlpatterns = [
    path('', Index.as_view(), name='homepage'),
    path('signup/', Signup.as_view(), name='signup'),
    path('login/', Login.as_view(), name='login'),
    path('logout/', views.logout, name='logout'),
    path('cart/', Cart.as_view(), name='cart'),
    path('checkout/', Checkout.as_view(), name='checkout'),
    path('order/', auth_middleware(OrderView.as_view()), name='order'),
]
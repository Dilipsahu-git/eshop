from django import template

register = template.Library()

#==== product is in cart======
@register.filter(name='is_in_cart')
def is_in_cart(product, cart):
    keys = cart.keys()
    for id in keys:
        if int(id) == product.id:
            return True
    return False

#====== particular product quantity in cart======
@register.filter(name='cart_quantity')
def cart_quantity(product, cart):
    keys = cart.keys()
    for id in keys:
        if int(id) == product.id:
            return cart.get(id)
    return 0

#======== total price of particular product quantity=====
@register.filter(name='product_quantity_total')
def product_quantity_total(product, cart):
    return product.price * cart_quantity(product, cart)


#======== total price of all product in cart======
@register.filter(name='total_cart_price')
def total_cart_price(products, cart):
    sum = 0
    for p in products:
        sum += product_quantity_total(p, cart)
    return sum

#========= add currency symbol========
@register.filter(name='currency_symbol')
def currency_symbol(product_price):
    return "₹ " + str(product_price)


#========== Multiply ========
@register.filter(name='multiply')
def multiply(number, number1):
    return number * number1

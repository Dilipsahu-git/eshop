from django.contrib import admin
from .models import Product, Category, Coustomer, Order

# To show admin models in table form..
class AdminProduct(admin.ModelAdmin):
    list_display = ['productname', 'category', 'price']

class AdminCategory(admin.ModelAdmin):
    list_display = ['name']

class AdminCoustomer(admin.ModelAdmin):
    list_display = ['first_name', 'last_name', 'phone']

# Register your models here.
admin.site.register(Product, AdminProduct)
admin.site.register(Category, AdminCategory)
admin.site.register(Coustomer, AdminCoustomer)
admin.site.register(Order)
from django.db import models
import datetime

# Create your models here.

# Creating product table in database
class Product(models.Model):
    productname = models.CharField(max_length=20)
    category = models.ForeignKey('Category', on_delete=models.CASCADE, default=1)
    price = models.IntegerField(default=0)
    description = models.CharField(max_length=200, default='', null=True, blank=True)
    image = models.ImageField(upload_to='product/img')


    @staticmethod
    def get_product_by_id(ids):
        return Product.objects.filter(id__in = ids)

    # getting all product from databse
    @staticmethod
    def get_all_products():
        return Product.objects.all()

    # filter product by category
    @staticmethod
    def get_all_products_by_categoryid(category_id):
        if category_id:
            return Product.objects.filter(category= category_id)

        else:
            return Product.get_all_products()



# creating category table in database
class Category(models.Model):
    name = models.CharField(max_length=20)

    @staticmethod
    def get_all_category():
        return Category.objects.all()

    def __str__(self):
        return self.name


# Creating coustomer table in database
class Coustomer(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    phone = models.CharField(max_length=15)
    email = models.EmailField()
    password = models.CharField(max_length=500)


    @staticmethod
    def get_user_by_email(email):
        try:
            return Coustomer.objects.get(email= email)
        except:
            return False
        

# checking email already exists or not.
    def isExists(self):
        if Coustomer.objects.filter(email = self.email):
            return True
        return False

# Creting order table to store order detials.
class Order(models.Model):
    product_item = models.ForeignKey(Product, on_delete=models.CASCADE)
    user = models.ForeignKey(Coustomer, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)
    price = models.IntegerField()
    date = models.DateField(default=datetime.datetime.today)
    address = models.CharField(max_length=300, default='', blank=True)
    phone = models.CharField(max_length=10, default='', blank=True)
    complete = models.BooleanField(default=False)

    def placeOrder(self):
        self.save()

    @staticmethod
    def get_orders_by_coustomer(coustomer_id):
        return Order.objects.filter(user = coustomer_id).order_by('-date')
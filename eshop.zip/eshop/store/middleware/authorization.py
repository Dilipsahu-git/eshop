from django.shortcuts import redirect


def auth_middleware(get_response):
    # One-time configuration and initialization.

    def middleware(request):
        # Code to be executed for each request before

        print('middleware')

        # getting request url which url give request to login here is order
        returnUrl = request.META['PATH_INFO']

        if not request.session.get('coustomer_id'):
            return redirect(f'login?return_url={returnUrl}')
        # the view (and later middleware) are called.

        response = get_response(request)

        # Code to be executed for each request/response after
        # the view is called.

        return response

    return middleware

from django.shortcuts import render, HttpResponse, redirect, HttpResponseRedirect
from .models import Product, Category, Coustomer, Order
from django.contrib.auth.hashers import make_password, check_password
from django.views import View
# from store.middleware.authorization import auth_middleware
# from django.utils.decorators import method_decorator
# =======HOMEPAGE====


class Index(View):
    def post(self, request):
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')

        if cart:
            quantity = cart.get(product)

            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity-1
                else:
                    cart[product] = quantity+1
            else:
                cart[product] = 1

        else:
            cart = {}
            cart[product] = 1
        request.session['cart'] = cart
        return redirect('homepage')

    def get(self, request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        products = None
        category = Category.get_all_category()
        category_id = request.GET.get('category')
        if category_id:
            products = Product.get_all_products_by_categoryid(category_id)
        else:
            products = Product.get_all_products()
        return render(request, 'index.html', {'products': products, 'categories': category})

# =======SIGNUP======


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postData = request.POST
        firstname = postData.get('firstname')
        lastname = postData.get('lastname')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')

        value = {
            'first_name': firstname,
            'last_name': lastname,
            'phone': phone,
            'email': email,
            'password': password
        }

        error_message = None
        coustomer = Coustomer(first_name=firstname, last_name=lastname,
                              phone=phone, email=email, password=password)

        # validation
        if not firstname:
            error_message = "First name required."
        elif len(firstname) < 3:
            error_message = "Name must be 3 character long."

        elif not lastname:
            error_message = "Last name required."
        elif len(lastname) < 3:
            error_message = "Last name must be 3 character long."

        elif not phone:
            error_message = "Phone required."
        elif len(phone) < 10:
            error_message = "Phone must be 10 Digit."

        elif not email:
            error_message = "Email required."
        elif len(email) < 5:
            error_message = "Email should check."

        elif not password:
            error_message = "Password required."
        elif len(password) < 5:
            error_message = "Password must be longer than 5 character."

        # email already exists or not.
        elif coustomer.isExists():
            error_message = "Email already exists."

        # saving
        if not error_message:
            coustomer.password = make_password(coustomer.password)
            coustomer.save()
            return redirect('homepage')

        else:
            data = {'error': error_message, 'values': value}
            return render(request, 'signup.html', data)

# =======LOGIN=======


class Login(View):

    return_url = None

    def get(self, request):
        Login.return_url = request.GET.get('return_url')
        return render(request, 'login.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        coustomer = Coustomer.get_user_by_email(email)
        error_message = None
        if coustomer:
            flag = check_password(password, coustomer.password)
            if flag:
                
                request.session['coustomer_id'] = coustomer.id
                
                #middleware logic
                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
                else:
                    Login.return_url = None
                    return redirect('homepage')

            else:
                error_message = "Invalid password"
        else:
            error_message = "Invalid email and password"
        return render(request, 'login.html', {'error': error_message})

# =======LOGOUT======


def logout(request):
    request.session.clear()
    return redirect('homepage')

# ========CART========


class Cart(View):
    def get(self, request):
        ids = list(request.session.get('cart').keys())
        products = Product.get_product_by_id(ids)
        return render(request, 'cart.html', {'products': products})

# =========CHECKOUT========


class Checkout(View):
    def post(self, request):
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        coustomer = request.session.get('coustomer_id')
        cart = request.session.get('cart')
        products = Product.get_product_by_id(list(cart.keys()))
        print(address, phone, coustomer, cart, products)
        for product in products:
            order = Order(product_item=product, user=Coustomer(id=coustomer), quantity=cart.get(
               str(product.id)), price=product.price, address=address, phone=phone)
            order.placeOrder()
        request.session['cart'] = {}
        return redirect('cart')

# =========ORDER========


class OrderView(View):
    def get(self, request):
        coustomer = request.session.get('coustomer_id')
        order = Order.get_orders_by_coustomer(coustomer)
        print(order)
        return render(request, 'order.html', {'orders':order})